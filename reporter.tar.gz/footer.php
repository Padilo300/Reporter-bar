
  <script src="js/anime.min.js"				         ></script>
  <script src="js/imagesloaded.pkgd.min.js"	   ></script>
  <script src="js/main.js"					           ></script>
  <script src='js/bootstrap.min.js' 		       ></script>
  <script src='libs/R_rest.js' 				         ></script>
  <script src="libs/R_pab.js" 				         ></script>
  <script src='libs/calendar_ARTIST.js' 	     ></script>
  <script src="libs/userSripts.js" 			       ></script>
  <script src="libs/calendar.js"               ></script>
  <script src="js/jquery.validate.min.js"	     ></script>
</body>
</html>