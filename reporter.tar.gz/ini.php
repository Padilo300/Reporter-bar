<?php 
phpinfo(); ?>