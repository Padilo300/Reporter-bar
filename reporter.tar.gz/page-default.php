<?php require_once 'head.php'; ?>
<body>
  <div class="container-fluid">
    <?php require_once 'php/part-page/nav-menu-main.php'  ; ?>
    <div class="row" id="ajax-conteiner">
    	
<?php require_once 'footer.php'; ?>