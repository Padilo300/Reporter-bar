<div class="col-lg-7 col-lg-offset-5 col-md-12 col-sm-12">
        <div class="cart-user">
          <div class="cart-user__header__fullName-users">
              <p><a href="#"><?php echo $user['first_name']; ?></a> <i>24 года</i></p>
            </div>
          <div class="cart-user__flex-conteiner">
          <div class="cart-user__foto-users">
              <img src="img/foto-users/user-defoult.jpg" alt="Фото сотрудника">
          </div>
          <header class="cart-user__header">
            <table class="table cart-user__header__tableInfo">
            <tbody>
              <tr>
                <th>Работает в:</th>
                <th><a href="#">Репортер</a> <br> Кафе</th>
              </tr>
              <tr>
                <th><i class="fa fa-phone" aria-hidden="true"></i> Номер телефона:</th>
                <th>
                  <a href="tel">0660405066</a>
                    <br>
                  <a href="tel">0660405066</a>
                </th>
              </tr>
              <tr>
                <th><i class="fa fa-at" aria-hidden="true"></i> Почта:</th>
                <th><a href="mailto:padilo300@gmail.com">padilo300@gmail.com</a></th>
              </tr>
              <tr>
                <th><i class="fa fa-id-card-o" aria-hidden="true"></i> Дата рождения:</th>
                <th>06.11.1994</th>
              </tr>
              <tr>
                <th><i class="fa fa-id-card-o" aria-hidden="true"></i> Адресс прописки:</th>
                <th>Пер.Баженова д11</th>
              </tr>
              <tr>
                <th><i class="fa fa-map-marker" aria-hidden="true"></i> Фактический адресс проживания:</th>
                <th>Ул. Инжинерная 2</th>
              </tr>
              <tr>
                <th></th>
              </tr>
            </tbody>
          </table>
          </header>
        </div>
        </div>
      </div>